[中文](readme_zh.md)

# Generate the download link of MIUI theme.
![无标题.jpg](https://i.loli.net/2018/09/09/5b94e4dbedde9.jpg)
-----
If you want to compile it by yourself. You need [libcurl](https://curl.haxx.se/download.html) and [jsoncpp](https://github.com/open-source-parsers/jsoncpp) installed.
And you need to build curl and json with `/MDd` for Debug and `/MD` for Release.

-----
# Dependence
 - [imgui](https://github.com/ocornut/imgui)(with glfw and opengl)
 - [jsoncpp](https://github.com/open-source-parsers/jsoncpp)
 - [libcurl](https://curl.haxx.se/download.html)

 -----
 If you got any problem about display just like this
 [![无标题3.jpg](https://i.loli.net/2018/08/20/5b7ad04a38da3.jpg)](https://i.loli.net/2018/08/20/5b7ad04a38da3.jpg)
Please delete the file `imgui.ini`.